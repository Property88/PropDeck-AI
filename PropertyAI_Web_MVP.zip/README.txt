PropertyAI Web MVP
Open index.html in a modern browser.
This is the mobile-friendly web-app prototype. It supports property details, photos, generated marketing copy, WhatsApp share/copy, and print/save PDF.
For a truly public online URL, upload the folder to a static hosting service or connect it to a hosting provider. No hosting account is included in this file.
